## Clarifier
A chrome extension to make what you read extra clear by replacing words with their definitions
